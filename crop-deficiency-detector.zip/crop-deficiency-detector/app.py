from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
import sqlite3
import os
import random
import datetime
import hashlib

app = Flask(__name__)
app.secret_key = 'crop-deficiency-secret-key-2024'
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

DATABASE = 'crop_deficiency.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'farmer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            image_filename TEXT NOT NULL,
            crop_type TEXT,
            deficiency_type TEXT,
            confidence REAL,
            recommendation TEXT,
            severity TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

# Simulated AI Model - Crop Nutrient Deficiency Detection
def simulate_ai_detection(image_path):
    """
    Simulated CNN model for crop nutrient deficiency detection.
    In production, this would be replaced with a trained CNN model.
    """
    crops = ['Tomato', 'Potato', 'Maize', 'Rice', 'Wheat', 'Cotton', 'Sugarcane']
    
    deficiencies = [
        {
            'type': 'Nitrogen Deficiency',
            'description': 'Yellowing of older leaves, stunted growth, reduced yield',
            'confidence': random.uniform(0.85, 0.98),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply Urea (46-0-0) at 50-100 kg/ha. Split application recommended. Also consider organic nitrogen sources like vermicompost.'
        },
        {
            'type': 'Phosphorus Deficiency',
            'description': 'Dark green or purple leaves, delayed maturity, poor root development',
            'confidence': random.uniform(0.82, 0.96),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply DAP (18-46-0) at 50-75 kg/ha. Use phosphorus-rich organic fertilizers. Ensure soil pH is between 6.0-7.0 for optimal uptake.'
        },
        {
            'type': 'Potassium Deficiency',
            'description': 'Yellowing or browning of leaf edges, weak stems, increased disease susceptibility',
            'confidence': random.uniform(0.80, 0.95),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply Muriate of Potash (MOP) at 50-100 kg/ha. Consider foliar spray of potassium nitrate for quick results.'
        },
        {
            'type': 'Iron Deficiency',
            'description': 'Interveinal chlorosis on young leaves, green veins with yellow tissue',
            'confidence': random.uniform(0.78, 0.93),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply chelated iron (Fe-EDTA) as foliar spray at 0.5-1%. Reduce soil pH with elemental sulfur. Avoid over-liming.'
        },
        {
            'type': 'Magnesium Deficiency',
            'description': 'Interveinal chlorosis on older leaves, leaf curling, premature defoliation',
            'confidence': random.uniform(0.76, 0.94),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply Magnesium Sulfate (Epsom Salt) at 20-40 kg/ha. Foliar spray with 2% MgSO4 solution. Apply dolomitic limestone.'
        },
        {
            'type': 'Healthy',
            'description': 'No nutrient deficiency detected. Crop appears healthy.',
            'confidence': random.uniform(0.85, 0.99),
            'severity': 'None',
            'recommendation': 'No fertilizer application needed. Continue with regular irrigation and pest management practices.'
        },
        {
            'type': 'Zinc Deficiency',
            'description': 'Shortened internodes, small leaves, white to yellow stripes between veins',
            'confidence': random.uniform(0.75, 0.92),
            'severity': random.choice(['Mild', 'Moderate', 'Severe']),
            'recommendation': 'Apply Zinc Sulfate at 25 kg/ha to soil. Foliar spray with 0.5% Zinc Sulfate solution. Apply during early growth stages.'
        }
    ]
    
    crop = random.choice(crops)
    deficiency = random.choice(deficiencies)
    
    return {
        'crop_type': crop,
        'deficiency_type': deficiency['type'],
        'description': deficiency['description'],
        'confidence': round(deficiency['confidence'], 2),
        'severity': deficiency['severity'],
        'recommendation': deficiency['recommendation']
    }

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.before_request
def check_auth():
    # Allow certain routes without authentication
    allowed_routes = ['login', 'register', 'static', 'api_register', 'api_login']
    if request.endpoint not in allowed_routes and 'user_id' not in session:
        if request.endpoint and request.endpoint.startswith('api_'):
            return jsonify({'error': 'Authentication required'}), 401
        return redirect(url_for('login'))

# ==================== API ROUTES ====================

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.get_json()
    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '')
    role = data.get('role', 'farmer')
    
    if not username or not email or not password:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400
    
    conn = get_db()
    try:
        conn.execute('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
                     (username, email, hash_password(password), role))
        conn.commit()
        return jsonify({'success': True, 'message': 'Registration successful'})
    except sqlite3.IntegrityError:
        return jsonify({'success': False, 'message': 'Username or email already exists'}), 400
    finally:
        conn.close()

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'success': False, 'message': 'Username and password are required'}), 400
    
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                       (username, hash_password(password))).fetchone()
    conn.close()
    
    if user:
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role'] = user['role']
        return jsonify({'success': True, 'message': 'Login successful', 'role': user['role']})
    else:
        return jsonify({'success': False, 'message': 'Invalid username or password'}), 401

@app.route('/api/detect', methods=['POST'])
def api_detect():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'}), 401
    
    if 'image' not in request.files:
        return jsonify({'success': False, 'message': 'No image file provided'}), 400
    
    image = request.files['image']
    if image.filename == '':
        return jsonify({'success': False, 'message': 'No image file selected'}), 400
    
    # Validate image extension
    allowed_extensions = {'png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp'}
    if not image.filename.rsplit('.', 1)[-1].lower() in allowed_extensions:
        return jsonify({'success': False, 'message': 'Invalid image format. Use PNG, JPG, JPEG, BMP, GIF, or WEBP'}), 400
    
    # Save image
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{session['username']}_{timestamp}.{image.filename.rsplit('.', 1)[-1].lower()}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    image.save(filepath)
    
    # Run AI detection
    result = simulate_ai_detection(filepath)
    result['image_filename'] = filename
    
    # Save report to database
    conn = get_db()
    conn.execute('''
        INSERT INTO reports (user_id, image_filename, crop_type, deficiency_type, 
                           confidence, recommendation, severity)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (session['user_id'], filename, result['crop_type'], result['deficiency_type'],
          result['confidence'], result['recommendation'], result['severity']))
    conn.commit()
    result['report_id'] = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
    conn.close()
    
    return jsonify({'success': True, 'data': result})

@app.route('/api/reports', methods=['GET'])
def api_reports():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'}), 401
    
    conn = get_db()
    reports = conn.execute('''
        SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC
    ''', (session['user_id'],)).fetchall()
    conn.close()
    
    reports_list = [dict(row) for row in reports]
    return jsonify({'success': True, 'data': reports_list})

@app.route('/api/reports/<int:report_id>', methods=['GET'])
def api_report_detail(report_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'}), 401
    
    conn = get_db()
    report = conn.execute('''
        SELECT * FROM reports WHERE id = ? AND user_id = ?
    ''', (report_id, session['user_id'])).fetchone()
    conn.close()
    
    if report:
        return jsonify({'success': True, 'data': dict(report)})
    else:
        return jsonify({'success': False, 'message': 'Report not found'}), 404

@app.route('/api/reports/<int:report_id>', methods=['DELETE'])
def api_delete_report(report_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'}), 401
    
    conn = get_db()
    conn.execute('DELETE FROM reports WHERE id = ? AND user_id = ?',
                 (report_id, session['user_id']))
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'message': 'Report deleted successfully'})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

# ==================== PAGE ROUTES ====================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/detect')
def detect():
    return render_template('detect.html')

@app.route('/results/<int:report_id>')
def results(report_id):
    return render_template('results.html', report_id=report_id)

@app.route('/reports')
def reports():
    return render_template('reports.html')

@app.route('/uploaded_images/<filename>')
def uploaded_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
