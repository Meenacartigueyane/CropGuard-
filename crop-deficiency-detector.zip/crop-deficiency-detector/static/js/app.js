// ===== API Helper =====
async function apiCall(endpoint, options = {}) {
    const response = await fetch(endpoint, {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    });
    return response.json();
}

// ===== Alert Helper =====
function showAlert(elementId, message, type = 'success') {
    const alert = document.getElementById(elementId);
    alert.className = `alert alert-${type} show`;
    alert.textContent = message;
    setTimeout(() => {
        alert.classList.remove('show');
    }, 5000);
}

// ===== Auth Pages =====
async function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    
    if (!username || !password) {
        showAlert('login-alert', 'Please fill in all fields', 'danger');
        return;
    }
    
    try {
        const data = await apiCall('/api/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        
        if (data.success) {
            window.location.href = '/dashboard';
        } else {
            showAlert('login-alert', data.message, 'danger');
        }
    } catch (error) {
        showAlert('login-alert', 'An error occurred. Please try again.', 'danger');
    }
}

async function handleRegister(event) {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    
    if (!username || !email || !password) {
        showAlert('register-alert', 'Please fill in all fields', 'danger');
        return;
    }
    
    if (password.length < 6) {
        showAlert('register-alert', 'Password must be at least 6 characters', 'danger');
        return;
    }
    
    try {
        const data = await apiCall('/api/register', {
            method: 'POST',
            body: JSON.stringify({ username, email, password, role })
        });
        
        if (data.success) {
            showAlert('register-alert', 'Registration successful! Redirecting to login...', 'success');
            setTimeout(() => {
                window.location.href = '/login';
            }, 2000);
        } else {
            showAlert('register-alert', data.message, 'danger');
        }
    } catch (error) {
        showAlert('register-alert', 'An error occurred. Please try again.', 'danger');
    }
}

async function handleLogout() {
    try {
        await apiCall('/api/logout', { method: 'POST' });
        window.location.href = '/login';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// ===== Detection Page =====
let selectedFile = null;

function setupDragDrop() {
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    
    if (!uploadArea || !fileInput) return;
    
    uploadArea.addEventListener('click', () => fileInput.click());
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('drag-over');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect(files[0]);
        }
    });
    
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    });
}

function handleFileSelect(file) {
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/bmp', 'image/gif', 'image/webp'];
    
    if (!allowedTypes.includes(file.type)) {
        showAlert('detect-alert', 'Please select a valid image file (PNG, JPG, JPEG, BMP, GIF, WEBP)', 'danger');
        return;
    }
    
    if (file.size > 16 * 1024 * 1024) {
        showAlert('detect-alert', 'File size must be less than 16MB', 'danger');
        return;
    }
    
    selectedFile = file;
    
    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        const previewSection = document.getElementById('preview-section');
        const previewImage = document.getElementById('preview-image');
        previewImage.src = e.target.result;
        previewSection.classList.add('active');
    };
    reader.readAsDataURL(file);
}

async function handleDetect() {
    if (!selectedFile) {
        showAlert('detect-alert', 'Please select an image first', 'danger');
        return;
    }
    
    const formData = new FormData();
    formData.append('image', selectedFile);
    
    const detectBtn = document.getElementById('detect-btn');
    const loadingOverlay = document.getElementById('loading-overlay');
    
    detectBtn.disabled = true;
    loadingOverlay.classList.add('active');
    
    try {
        const response = await fetch('/api/detect', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.success) {
            window.location.href = `/results/${data.data.report_id}`;
        } else {
            showAlert('detect-alert', data.message, 'danger');
            detectBtn.disabled = false;
            loadingOverlay.classList.remove('active');
        }
    } catch (error) {
        showAlert('detect-alert', 'An error occurred during detection. Please try again.', 'danger');
        detectBtn.disabled = false;
        loadingOverlay.classList.remove('active');
    }
}

// ===== Results Page =====
async function loadResults(reportId) {
    try {
        const data = await apiCall(`/api/reports/${reportId}`);
        
        if (data.success) {
            const result = data.data;
            displayResults(result);
        } else {
            showAlert('results-alert', data.message, 'danger');
        }
    } catch (error) {
        showAlert('results-alert', 'Failed to load results. Please try again.', 'danger');
    }
}

function displayResults(result) {
    document.getElementById('result-deficiency').textContent = result.deficiency_type;
    document.getElementById('result-crop').textContent = result.crop_type;
    document.getElementById('result-severity').textContent = result.severity;
    document.getElementById('result-confidence').textContent = (result.confidence * 100).toFixed(1) + '%';
    document.getElementById('result-description').textContent = result.description;
    document.getElementById('result-recommendation').textContent = result.recommendation;
    document.getElementById('result-date').textContent = result.created_at;
    
    // Set confidence bar
    const confidenceBar = document.getElementById('confidence-fill');
    if (confidenceBar) {
        confidenceBar.style.width = (result.confidence * 100) + '%';
    }
    
    // Set severity badge color
    const severityBadge = document.getElementById('severity-badge');
    severityBadge.className = 'severity-badge';
    if (result.severity.toLowerCase() === 'mild') {
        severityBadge.classList.add('severity-mild');
    } else if (result.severity.toLowerCase() === 'moderate') {
        severityBadge.classList.add('severity-moderate');
    } else if (result.severity.toLowerCase() === 'severe') {
        severityBadge.classList.add('severity-severe');
    }
}

// ===== Reports Page =====
async function loadReports() {
    try {
        const data = await apiCall('/api/reports');
        
        if (data.success && data.data.length > 0) {
            displayReports(data.data);
        } else {
            document.getElementById('reports-table-container').innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📋</div>
                    <h3>No Reports Yet</h3>
                    <p>Upload a crop leaf image to get your first detection report.</p>
                    <a href="/detect" class="btn-detect" style="margin-top: 1rem; text-decoration: none;">
                        Detect Now
                    </a>
                </div>
            `;
        }
    } catch (error) {
        showAlert('reports-alert', 'Failed to load reports. Please try again.', 'danger');
    }
}

function displayReports(reports) {
    let html = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Crop Type</th>
                    <th>Deficiency</th>
                    <th>Confidence</th>
                    <th>Severity</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    reports.forEach(report => {
        const severityClass = report.severity.toLowerCase() === 'mild' ? 'severity-mild' : 
                             report.severity.toLowerCase() === 'moderate' ? 'severity-moderate' : 'severity-severe';
        const date = new Date(report.created_at).toLocaleDateString();
        
        html += `
            <tr>
                <td>${date}</td>
                <td>${report.crop_type}</td>
                <td>${report.deficiency_type}</td>
                <td>${(report.confidence * 100).toFixed(1)}%</td>
                <td><span class="severity-badge ${severityClass}">${report.severity}</span></td>
                <td>
                    <button class="btn-view" onclick="window.location.href='/results/${report.id}'">View</button>
                    <button class="btn-delete" onclick="deleteReport(${report.id})">Delete</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    
    document.getElementById('reports-table-container').innerHTML = html;
}

async function deleteReport(reportId) {
    if (!confirm('Are you sure you want to delete this report?')) return;
    
    try {
        const data = await apiCall(`/api/reports/${reportId}`, { method: 'DELETE' });
        if (data.success) {
            showAlert('reports-alert', 'Report deleted successfully', 'success');
            loadReports(); // Reload reports
        } else {
            showAlert('reports-alert', data.message, 'danger');
        }
    } catch (error) {
        showAlert('reports-alert', 'Failed to delete report. Please try again.', 'danger');
    }
}

// ===== Dashboard =====
async function loadDashboard() {
    try {
        const data = await apiCall('/api/reports');
        if (data.success) {
            const totalReports = data.data.length;
            document.getElementById('total-reports').textContent = totalReports;
            
            // Count deficiencies
            const deficiencyCount = data.data.filter(r => r.deficiency_type !== 'Healthy').length;
            document.getElementById('deficiency-found').textContent = deficiencyCount;
            
            // Count healthy
            const healthyCount = data.data.filter(r => r.deficiency_type === 'Healthy').length;
            document.getElementById('healthy-crops').textContent = healthyCount;
            
            // Set user greeting
            const username = document.getElementById('user-name');
            if (username) username.textContent = username.dataset.name || 'User';
        }
    } catch (error) {
        console.error('Dashboard load error:', error);
    }
}

// ===== Initialize Pages =====
document.addEventListener('DOMContentLoaded', () => {
    // Setup drag and drop on detect page
    setupDragDrop();
    
    // Load dashboard data
    if (document.getElementById('total-reports')) {
        loadDashboard();
    }
    
    // Load results
    const resultsContainer = document.getElementById('results-container');
    if (resultsContainer) {
        const reportId = resultsContainer.dataset.reportId;
        if (reportId) {
            loadResults(reportId);
        }
    }
    
    // Load reports
    if (document.getElementById('reports-table-container')) {
        loadReports();
    }
});
